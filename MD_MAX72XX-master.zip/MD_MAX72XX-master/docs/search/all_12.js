var searchData=
[
  ['wraparound',['WRAPAROUND',['../class_m_d___m_a_x72_x_x.html#a7c6d702fe0161b19448f35049e00bf4fa730720f52539695efa6d004046981827',1,'MD_MAX72XX::WRAPAROUND()'],['../class_m_d___m_a_x72_x_x.html#a0b5940c115ad58aeb05d7af1e9162f97',1,'MD_MAX72XX::wraparound(controlValue_t mode)']]]
];
